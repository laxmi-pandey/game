﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BGame
{
    [TestClass]
    public class UnitTest1
    {
        private BowlingGame.BowlGame game;

        [TestInitialize]
        public void Initialize()
        {
            game = new BowlingGame.BowlGame();
        }

        [TestMethod]
        public void CanRollGame()
        {
            RollMany(0, 20);
            Assert.AreEqual(0, game.Score);
        }

        [TestMethod]
        public void CanRollAllOnes()
        {
            RollMany(1, 20);
            Assert.AreEqual(20, game.Score);
        }

        [TestMethod]
        public void CanRollSpare()
        {
            game.Roll(5);
            game.Roll(5);
            game.Roll(3);
            RollMany(0, 17);
            Assert.AreEqual(16, game.Score);

        }


        [TestMethod]
        public void CanRollStrike()
        {
            game.Roll(10);
            game.Roll(3);
            game.Roll(4);
            RollMany(0, 16);
            Assert.AreEqual(24, game.Score);

        }


        [TestMethod]
        public void CanRollPerfect()
        {
            RollMany(10, 12);
            Assert.AreEqual(300, game.Score);

        }
        private void RollMany(int pins, int rolls)
        {
            for (int i = 0; i < rolls; i++)
                game.Roll(pins);
        }

    }
}
